const http = require('http');
const url = require('url');
const got = require('got');

const KittyChongUserId = '6343fb91edfc4e4409539ddf';
const NicoleAdamsUserId = '6343ebb4edfc4e4409534e53';

const headers = { Authorization: 'Basic NjM0M2Y2MWY0OGFjZTcwNGNlOWNmYmNlOmJoSkp5Lm9zWDMzODtZLDJSUWJ4TkkwK0hYbXIub28xVUwzVzdNY21vfUFTYzFwQWdFekRyRy5IbGNleDEpQ2Q='};

http.createServer(onRequest).listen(8888);
console.log('Fish App Server has started');

const searchSBUsers = async(query) => {
    try {
        const res = await got
            .get('https://app.staffbase.com/api/users/' + query, {headers})
            .json();
        //console.log(res);
        return res;
    } catch (err) {
        console.log(err);
    }
}

const getSBUserById = async(userid) => {
    try {
        const res = await got
            .get('https://app.staffbase.com/api/users/' + userid, {headers})
            .json();
        return res;
    } catch (err) {
        console.log(err);
    }
}

const sendNotification = async(notificationRecipient, notificationContent) => {
    try {
        const res = await got
            .post('http://app.staffbase.com/api/notifications/',
                 {
                    headers,
                    json:
                    {
                        "recipients": {
                            "accessorIds": [
                                notificationRecipient
                            ]
                        },
                        "content": {
                            "en_US": {
                                "title": notificationContent
                            }
                        }
                    }
                })
            .json();
        return res;
    } catch (err) {
        console.log(err);
    }
}

function onRequest(request, response) {
    var query = url.parse(request.url, true).query;
    let userid = query?.userid;

    response.writeHead(200);

    if (userid)
    {
        response.write('Received request from user:' + userid);

        getSBUserById(userid).then( (res) => {
            const firstName = res.firstName;
            const lastName = res.lastName;
            const fullName = firstName + ' ' + lastName;
            console.log('User data retrieved from SB: ' + fullName);
        
            const message = fullName + '  has sent you 5 fish!';
        
            sendNotification(NicoleAdamsUserId, message).then( (res) => {
                console.log('Notification sent');
                console.log('Recipient: ' + NicoleAdamsUserId);
                console.log('Content: ' + message);
                console.log(res);
            })
        });

    } else {
        response.write('No userid provided in query string');
    }
    
    response.end();
    

}