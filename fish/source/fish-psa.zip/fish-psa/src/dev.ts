/*!
 * Copyright 2021, Staffbase GmbH and contributors.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * This polyfills are representing the available ones in the
 * hosting application. You don't need to take care about that ones
 */
import "core-js/stable";
import "regenerator-runtime/runtime";
import "minimal-polyfills/Array.prototype.find";
import "minimal-polyfills/String.prototype.startsWith";
import "minimal-polyfills/Array.from";
import "minimal-polyfills/ArrayBuffer.isView";
import "minimal-polyfills/Object.fromEntries";
import "minimal-polyfills/Object.is";
import "minimal-polyfills/Object.assign";
import "@ungap/custom-elements";
import "core-js/es/reflect";
import "core-js/es/array";

import "./index";
