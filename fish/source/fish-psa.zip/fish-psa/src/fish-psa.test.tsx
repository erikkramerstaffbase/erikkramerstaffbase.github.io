import React from "react"
import {screen, render} from "@testing-library/react"

import {FishPsa} from "./fish-psa";

describe("FishPsa", () => {
    it("should render the component", () => {
        render(<FishPsa contentLanguage="en_US" message="World"/>);

        expect(screen.getByText(/Hello World/)).toBeInTheDocument();
    })
})
